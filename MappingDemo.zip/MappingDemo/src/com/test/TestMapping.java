package com.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class TestMapping {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		//Here we do persist one to one
		/*Employee emp = new Employee();
		emp.setEmployeeName("Kavita");
		Department dept = new Department();
		dept.setDepartmentName("Marketing");
		
		//Now set department to employee
		emp.setDepartment(dept);
		
		//Now to persist emp (here emp persist child also)
		em.persist(emp);
		em.persist(dept);
		
		em.persist(emp);*/
		
		/*
		//Here we get department information also through employee
		Employee emp = em.find(Employee.class, 1);
		System.out.println(emp.getEmployeeName());
		System.out.println(emp.getDepartment().getDepartmentName()+" "+emp.getEmployeeName());*/
		
		/*Employee emp = em.find(Employee.class, 1);
		em.remove(emp);*/
		
		//Here we put ftech type = lazy
		/*Employee emp = em.find(Employee.class, 3);
		System.out.println(emp.getEmployeeName());*/
		
		//Bidirectrional...Display employee deatails where department id is 3.
		Department dept = em.find(Department.class, 3);
		
		
		String qryStr="from Employee where department.departmentId=3";
		TypedQuery<Employee> qry = em.createQuery(qryStr,Employee.class);
		List<Employee> list = qry.getResultList();
		for(Employee emp3  : list)
		{
			System.out.println(emp3.getEmployeeName()+" "+emp3.getEmployeeId()+" "+emp3.getDepartment().getDepartmentId());
		}
		
		
		em.getTransaction().commit();
		System.out.println(" Employee removed ");
		em.close();
		emf.close();
		

	}

}
