package com.capgemini.fms.test;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.dao.AdminDao;
import com.capgemini.fms.dao.AdminDaoImpl;
import com.capgemini.fms.exception.FeedbackException;

public class AdminTest {
	AdminDao dao= new AdminDaoImpl();
AdminDaoImpl admin=new AdminDaoImpl();
	@Test
	public void testGetSkillset() throws FeedbackException {
	assertEquals("Testing", admin.getSkillset(10003));
	}

	

	@Test
	public void testGetEmployees() throws FeedbackException {
		HashMap<Integer, Employee> employee=new HashMap<Integer, Employee>();
		assertEquals(employee, dao.getEmployees());
	}

	@Test
	public void testGetEmployeeById() {
		assertNotNull(13068);
	}

	@Test
	public void testGetUser() throws FeedbackException {
		assertEquals("Participant", dao.getUser(13069, "pass123"));
	}

	//Throwing exception..i dont have course seq
	@Test
	public void testAddCourse() throws FeedbackException {
	
		assertEquals(3,dao.addCourse( new Course("JPA",5)));
	}

	//I dont coursesequence
//	@Test
//	public void testGetCourseId() {
//		assertEquals(4, dao.ge);
//	}

	@Test
	public void testGetCourses() throws FeedbackException {
		assertNotNull(dao.getCourses());
	}

}
