package com.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.capgemini.fms.bean.FeedBack;
import com.capgemini.fms.bean.TrainingProgram;
import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.logging.MyLogger;
import com.capgemini.fms.util.DBUtil;
import com.capgemini.fms.queries.IQueryMapper;

public class ParticipantDAOImpl implements ParticipantDAO {
	Connection con=DBUtil.getConnect(); ;
	MyLogger logger=new MyLogger();
	public Logger log=logger.getLog();
	@Override
	public HashMap<Integer, String> getTrainingListByParticipantID(int traineeId)
			throws FeedbackException {

		ArrayList<Integer> trainingIdList = new ArrayList<Integer>();
		HashMap<Integer, String> tempMap;
		HashMap<Integer, String> courseMap = new HashMap<Integer, String>();
		trainingIdList = getTrainingId(traineeId);
		Iterator<Integer> itr = trainingIdList.iterator();
		while (itr.hasNext()) {
			int trainingId = itr.next();
			tempMap = getTrainingList(trainingId);

			courseMap.put(trainingId, tempMap.get(trainingId));

		}
		return courseMap;
	}

	public HashMap<Integer, String> getTrainingList(int trainingId)
			throws FeedbackException {
		String courseName;
		// TrainingProgramBean trainingBean=null;
		HashMap<Integer, String> courseMap = new HashMap<Integer, String>();
		String sql = IQueryMapper.GetTrainingList;
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, trainingId);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				courseName = result.getString(4);
				courseMap.put(result.getInt(1), courseName);

			} else{
				
				log.error("Training ID doesnt Exist");
				throw new FeedbackException("Training ID  does not Exist");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new FeedbackException(e.getMessage());
		}

		return courseMap;
	}

	private ArrayList<Integer> getTrainingId(int traineeId) throws FeedbackException {
		ArrayList< Integer> list=new ArrayList<Integer>();
		
	
		String sql=IQueryMapper.GetTrainingId;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, traineeId);
			ResultSet result=pstmt.executeQuery();
			
			while(result.next())
			{
				list.add(result.getInt(1));
				
			}
		}catch(Exception e)
			{
			throw new FeedbackException(e.getMessage());
			}
		return list;
		
	}

	@Override
	public TrainingProgram getTrainingDetails(int trainingId)
			throws FeedbackException {
		TrainingProgram trainingBean = null;
		String sql = IQueryMapper.GetTrainingDetails;
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, trainingId);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				trainingBean = new TrainingProgram();
				trainingBean.setTraining_code(trainingId);
				trainingBean.setCourseID(result.getInt(2));
				trainingBean.setFacultyCode(result.getInt(3));
				Date startDate = result.getDate(4);
				trainingBean.setStartDate(startDate.toLocalDate());
				Date endDate = result.getDate(5);
				trainingBean.setEndDate(endDate.toLocalDate());
			} else{
				log.error("Training details doesnt Exist");
				throw new FeedbackException("Training details doesnt Exist");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new FeedbackException(e.getMessage());
		}
		return trainingBean;
	}

	@Override
	public void addFeedback(FeedBack feedback) throws FeedbackException {

		String sql = IQueryMapper.AddFeedback;
		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setInt(1, feedback.getTrainingCode());
			stmt.setInt(2, feedback.getParticipantId());
			stmt.setInt(3, feedback.getFbPrsComm());
			stmt.setInt(4, feedback.getFbClrfyDbts());
			stmt.setInt(5, feedback.getFbTM());
			stmt.setInt(6, feedback.getFbHndOut());
			stmt.setInt(7, feedback.getFbHwSwNtwrk());
			stmt.setString(8, feedback.getComments());
			stmt.setString(9, feedback.getSuggestions());

			int row = stmt.executeUpdate();
			if (row == 1) {
				log.info("Feedback added by Participant with ID:"+feedback.getParticipantId()+" for Training ID:"+feedback.getTrainingCode());
				System.out.println("Thank You for Your FeedBack");
			} else{
				log.error("Error add Feedback");
				throw new FeedbackException("Sorry for Inconvenience");
			}
		} catch (SQLException e) {
			log.error("Exception Occured: "+e.getMessage());
			throw new FeedbackException(e.getMessage());
		}

	}

}
