package com.capgemini.fms.bean;

import java.time.LocalDate;

public class TrainingProgram {
	private int Training_code;
	private int CourseID;
	private int FacultyCode;
	private LocalDate StartDate;
	private LocalDate EndDate;

	public TrainingProgram() {
		super();
	}

	public int getTraining_code() {
		return Training_code;
	}

	public void setTraining_code(int training_code) {
		Training_code = training_code;
	}

	public int getCourseID() {
		return CourseID;
	}

	public void setCourseID(int courseID) {
		CourseID = courseID;
	}

	public int getFacultyCode() {
		return FacultyCode;
	}

	public void setFacultyCode(int facultyCode) {
		FacultyCode = facultyCode;
	}

	public LocalDate getStartDate() {
		return StartDate;
	}

	public void setStartDate(LocalDate startDate) {
		StartDate = startDate;
	}

	public LocalDate getEndDate() {
		return EndDate;
	}

	public void setEndDate(LocalDate endDate) {
		EndDate = endDate;
	}

	public TrainingProgram(int training_code, int courseID, int facultyCode,
			LocalDate startDate, LocalDate endDate) {
		super();
		Training_code = training_code;
		CourseID = courseID;
		FacultyCode = facultyCode;
		StartDate = startDate;
		EndDate = endDate;
	}

	/**
	 * @param courseID
	 * @param facultyCode
	 * @param startDate
	 * @param endDate
	 */
	public TrainingProgram(int courseID, int facultyCode, LocalDate startDate,
			LocalDate endDate) {
		super();
		CourseID = courseID;
		FacultyCode = facultyCode;
		StartDate = startDate;
		EndDate = endDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + CourseID;
		result = prime * result + ((EndDate == null) ? 0 : EndDate.hashCode());
		result = prime * result + FacultyCode;
		result = prime * result
				+ ((StartDate == null) ? 0 : StartDate.hashCode());
		result = prime * result + Training_code;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrainingProgram other = (TrainingProgram) obj;
		if (CourseID != other.CourseID)
			return false;
		if (EndDate == null) {
			if (other.EndDate != null)
				return false;
		} else if (!EndDate.equals(other.EndDate))
			return false;
		if (FacultyCode != other.FacultyCode)
			return false;
		if (StartDate == null) {
			if (other.StartDate != null)
				return false;
		} else if (!StartDate.equals(other.StartDate))
			return false;
		if (Training_code != other.Training_code)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TrainingProgram [Training_code=" + Training_code
				+ ", CourseID=" + CourseID + ", FacultyCode=" + FacultyCode
				+ ", StartDate=" + StartDate + ", EndDate=" + EndDate + "]";
	}

}
