package com.capgemini.fms.bean;

public class FeedBack {
	private int trainingCode;
	private int participantId;
	private  int fbPrsComm;
	private  int fbClrfyDbts;
	private  int fbTM;
	private  int fbHndOut;
	private  int fbHwSwNtwrk;
	private String comments;
	private String suggestions;

public int getTrainingCode() {
	return trainingCode;
}
public void setTrainingCode(int trainingCode) {
	this.trainingCode = trainingCode;
}
public int getParticipantId() {
	return participantId;
}
public void setParticipantId(int participantId) {
	this.participantId = participantId;
}
public int getFbPrsComm() {
	return fbPrsComm;
}
public void setFbPrsComm(int fbPrsComm) {
	this.fbPrsComm = fbPrsComm;
}
public int getFbClrfyDbts() {
	return fbClrfyDbts;
}
public void setFbClrfyDbts(int fbClrfyDbts) {
	this.fbClrfyDbts = fbClrfyDbts;
}
public int getFbTM() {
	return fbTM;
}
public void setFbTM(int fbTM) {
	this.fbTM = fbTM;
}
public int getFbHndOut() {
	return fbHndOut;
}
public void setFbHndOut(int fbHndOut) {
	this.fbHndOut = fbHndOut;
}
public int getFbHwSwNtwrk() {
	return fbHwSwNtwrk;
}
public void setFbHwSwNtwrk(int fbHwSwNtwrk) {
	this.fbHwSwNtwrk = fbHwSwNtwrk;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
public String getSuggestions() {
	return suggestions;
}
public void setSuggestions(String suggestions) {
	this.suggestions = suggestions;
}
public FeedBack() {
	super();
}

public FeedBack(int trainingCode, int participantId, int fbPrsComm,
		int fbClrfyDbts, int fbTM, int fbHndOut, int fbHwSwNtwrk,
		String comments, String suggestions) {
	super();
	this.trainingCode = trainingCode;
	this.participantId = participantId;
	this.fbPrsComm = fbPrsComm;
	this.fbClrfyDbts = fbClrfyDbts;
	this.fbTM = fbTM;
	this.fbHndOut = fbHndOut;
	this.fbHwSwNtwrk = fbHwSwNtwrk;
	this.comments = comments;
	this.suggestions = suggestions;
}
public FeedBack(int fbPrsComm, int fbClrfyDbts, int fbTM, int fbHndOut,
		int fbHwSwNtwrk, String comments, String suggestions) {
	super();
	this.fbPrsComm = fbPrsComm;
	this.fbClrfyDbts = fbClrfyDbts;
	this.fbTM = fbTM;
	this.fbHndOut = fbHndOut;
	this.fbHwSwNtwrk = fbHwSwNtwrk;
	this.comments = comments;
	this.suggestions = suggestions;
}
@Override
public String toString() {
	return "FeedBackBean [trainingCode=" + trainingCode + ", participantId="
			+ participantId + ", fbPrsComm=" + fbPrsComm + ", fbClrfyDbts="
			+ fbClrfyDbts + ", fbTM=" + fbTM + ", fbHndOut=" + fbHndOut
			+ ", fbHwSwNtwrk=" + fbHwSwNtwrk + ", comments=" + comments
			+ ", suggestions=" + suggestions + "]";
}



}
