package com.capgemini.fms.bean;

import java.time.LocalDate;

public class ReportBean {
	private int trainingCode;
	private String participantName;
	private int participantId;
	private String FacultyName;
	//private String courseName;
private  int fbPrsComm;
private  int fbClrfyDbts;
private  int fbTM;
private  int fbHndOut;
private  int fbHwSwNtwrk;
private LocalDate date;
/**
 * @param trainingCode
 * @param participantName
 * @param participantId
 * @param facultyName
 * @param fbPrsComm
 * @param fbClrfyDbts
 * @param fbTM
 * @param fbHndOut
 * @param fbHwSwNtwrk
 * @param date
 */
public ReportBean(int trainingCode, String participantName, int participantId,
		String facultyName, int fbPrsComm, int fbClrfyDbts, int fbTM,
		int fbHndOut, int fbHwSwNtwrk, LocalDate date) {
	super();
	this.trainingCode = trainingCode;
	this.participantName = participantName;
	this.participantId = participantId;
	FacultyName = facultyName;
	this.fbPrsComm = fbPrsComm;
	this.fbClrfyDbts = fbClrfyDbts;
	this.fbTM = fbTM;
	this.fbHndOut = fbHndOut;
	this.fbHwSwNtwrk = fbHwSwNtwrk;
	this.date = date;
}
/**
 * 
 */
public ReportBean() {
	super();
	// TODO Auto-generated constructor stub
}
public int getTrainingCode() {
	return trainingCode;
}
public void setTrainingCode(int trainingCode) {
	this.trainingCode = trainingCode;
}
public String getParticipantName() {
	return participantName;
}
public void setParticipantName(String participantName) {
	this.participantName = participantName;
}
public int getParticipantId() {
	return participantId;
}
public void setParticipantId(int participantId) {
	this.participantId = participantId;
}
public String getFacultyName() {
	return FacultyName;
}
public void setFacultyName(String facultyName) {
	FacultyName = facultyName;
}
public int getFbPrsComm() {
	return fbPrsComm;
}
public void setFbPrsComm(int fbPrsComm) {
	this.fbPrsComm = fbPrsComm;
}
public int getFbClrfyDbts() {
	return fbClrfyDbts;
}
public void setFbClrfyDbts(int fbClrfyDbts) {
	this.fbClrfyDbts = fbClrfyDbts;
}
public int getFbTM() {
	return fbTM;
}
public void setFbTM(int fbTM) {
	this.fbTM = fbTM;
}
public int getFbHndOut() {
	return fbHndOut;
}
public void setFbHndOut(int fbHndOut) {
	this.fbHndOut = fbHndOut;
}
public int getFbHwSwNtwrk() {
	return fbHwSwNtwrk;
}
public void setFbHwSwNtwrk(int fbHwSwNtwrk) {
	this.fbHwSwNtwrk = fbHwSwNtwrk;
}
public LocalDate getDate() {
	return date;
}
public void setDate(LocalDate date) {
	this.date = date;
}
@Override
public String toString() {
	return "ReportBean [trainingCode=" + trainingCode + ", participantName="
			+ participantName + ", participantId=" + participantId
			+ ", FacultyName=" + FacultyName + ", fbPrsComm=" + fbPrsComm
			+ ", fbClrfyDbts=" + fbClrfyDbts + ", fbTM=" + fbTM + ", fbHndOut="
			+ fbHndOut + ", fbHwSwNtwrk=" + fbHwSwNtwrk + ", date=" + date
			+ "]";
}


}
