package com.capgemini.fms.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.fms.bean.FeedBack;
import com.capgemini.fms.bean.TrainingProgram;
import com.capgemini.fms.dao.ParticipantDAO;
import com.capgemini.fms.dao.ParticipantDAOImpl;
import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.util.DBUtil;

public class ParticipantServiceImpl  implements ParticipantService{
	ParticipantDAO dao;
	
	public void setDAO(ParticipantDAO dao){
		this.dao=dao;
	}
	public ParticipantServiceImpl ()
	{
		dao=new ParticipantDAOImpl();
	}
	
	public static boolean checkExistingFeedback(int trainingId,int participantId) throws FeedbackException
	{	boolean flag=false;
		Connection con;
		con=DBUtil.getConnect();
		String sql="SELECT  * FROM FEEDBACK_MASTER where Training_code=? AND ParticipantId=?";
		
		
			try {
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.setInt(1, trainingId);
				pstmt.setInt(2, participantId);
				ResultSet result=pstmt.executeQuery();
				if(result.next())
				
					flag=false;
				
				else
					flag=true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new FeedbackException(e);
			}
				
	return flag;
		
	}
	
	public static boolean confirmEmptyValues(FeedBack bean)
	{
		boolean flag=true;
	List<Integer> list=new ArrayList<Integer>();
	list.add(bean.getFbPrsComm());
	list.add(bean.getFbHndOut());
	list.add(bean.getFbClrfyDbts());
	list.add(bean.getFbTM());
	list.add(bean.getFbHwSwNtwrk());
	for (Integer integer : list) {
		if(integer==0)
		{
			flag=false;
			break;
		}	
	}
		
		return flag;
	}
	
	/*public static boolean validateTrainingId(int traineeId) throws SQLException
	{
		String id=String.valueOf(traineeId);
		if(Pattern.matches("[0-9]{3}", id))
		{	
			Connection con;
			con=DBUtil.getConnect();
		
		String sql="SELECT  * FROM TRAINING_PROGRAM where Training_code="+traineeId;
		
			Statement stmt=con.createStatement();
			ResultSet result=stmt.executeQuery(sql);
			if(result.next())
			{
				return true;
			}
			else
				return false;
		}
		else 
		{
			return false;
		}	
	}*/
	
	public static boolean validateRating(int rating)
	{
		if(rating>=1 && rating<=5)
			return true;
		else
			return false;
	}
	
	public static boolean validateStringForInteger(String number)
	{	if(!number.isEmpty()){
		String validNumber=String.valueOf(number);
		if(Pattern.matches("[0-9]{0,5}", validNumber))
		return true;
		else
		return false;
	}
	else
	{
		
		return true;
	}
	}
	public static boolean validateStringSize(String string)
	{	
		if(string.length()<=200)
		return true;
		else
		return false;
		
	}

	@Override
	public HashMap<Integer, String> getTrainingListByParticipantID(int traineeId)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.getTrainingListByParticipantID(traineeId);
	}

	@Override
	public TrainingProgram getTrainingDetails(int trainingId)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.getTrainingDetails(trainingId);
	}

	@Override
	public void addFeedback(FeedBack feedback) throws FeedbackException {
	
	dao.addFeedback(feedback);	
	}
}
