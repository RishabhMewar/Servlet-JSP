package com.capgemini.fms.service;

import java.util.ArrayList;
import com.capgemini.fms.bean.ReportBean;
import com.capgemini.fms.dao.ReportDao;
import com.capgemini.fms.dao.ReportDaoImpl;
import com.capgemini.fms.exception.FeedbackException;

public class ReportServiceImpl implements ReportService {

	private ReportDao dao= new ReportDaoImpl();

	@Override
	public ArrayList<ReportBean> getAllTrainingReport(int month)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.getAllTrainingReport(month);
	}


	@Override

	public ArrayList<ReportBean> getFacultyReport(int facultyId,int month)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.getFacultyReport(facultyId, month);
	}

	@Override
	public ArrayList<ReportBean> getDefaulterReport(int month)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.getDefaulterReport(month);
	}

	
}
