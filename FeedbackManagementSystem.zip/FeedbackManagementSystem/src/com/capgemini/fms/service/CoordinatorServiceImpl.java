package com.capgemini.fms.service;

import java.util.HashMap;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.bean.TrainingProgram;
import com.capgemini.fms.dao.CoordinatorDao;
import com.capgemini.fms.dao.CoordinatorDaoImpl;
import com.capgemini.fms.exception.FeedbackException;

public class CoordinatorServiceImpl implements CoordinatorService {

	CoordinatorDao dao;

	public CoordinatorServiceImpl() {
		dao = new CoordinatorDaoImpl();
	}

	@Override
	public int addTrainingProgarm(TrainingProgram trainingProgram)
			throws FeedbackException {

		return dao.addTrainingProgarm(trainingProgram);
	}

	@Override
	public HashMap<Integer, Course> getcourseNames() {

		return dao.getcourseNames();
	}

	@Override
	public HashMap<Integer, Employee> getFaculties() {
		return dao.getFaculties();
	}

	@Override
	public void updateTraining(TrainingProgram trainingProgram)
			throws FeedbackException {
		dao.updateTraining(trainingProgram);
	}

	@Override
	public TrainingProgram getTrainingById(int trainingId) {
		return dao.getTrainingById(trainingId);
	}

	@Override
	public void deleteTrainingProgarm(int trainingId)
			throws FeedbackException {
		dao.deleteTrainingProgarm(trainingId);

	}

	@Override
	public void addParticipant(String courseName, int employeeId)
			throws FeedbackException {
		dao.addParticipant(courseName, employeeId);

	}

}
