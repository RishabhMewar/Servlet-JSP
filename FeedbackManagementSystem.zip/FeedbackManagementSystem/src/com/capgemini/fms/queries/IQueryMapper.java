package com.capgemini.fms.queries;

public interface IQueryMapper {
String GetTrainingList="SELECT a.Training_code,a.COURSEID,a.FacultyCode,b.CourseName from TRAINING_PROGRAM a,COURSE_MASTER b  WHERE  b.COURSEID=a.COURSEID AND Training_code=?";
String  GetTrainingId="SELECT Training_code from TRAINING_ENROLLMENT WHERE ParticipantId=?";
String GetTrainingDetails="SELECT Training_code,COURSEID,FacultyCode,StartDate,EndDate from TRAINING_PROGRAM  WHERE  Training_code=?";
String AddFeedback="INSERT INTO FEEDBACK_MASTER VALUES(?,?,?,?,?,?,?,?,?)";
}
