package com.capgemini.swissbank.bean;

import java.util.Date;

public class ServiceTrackerBean {
	private int serviceId;
	private String serviceDesc;
	private int accId;
	private Date serviceRaisedDate;
	private String status;
	public ServiceTrackerBean() {
		super();
	}
	public ServiceTrackerBean(int serviceId, String serviceDesc, int accId,
			Date serviceRaisedDate, String status) {
		super();
		this.serviceId = serviceId;
		this.serviceDesc = serviceDesc;
		this.accId = accId;
		this.serviceRaisedDate = serviceRaisedDate;
		this.status = status;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceDesc() {
		return serviceDesc;
	}
	public void setServiceDesc(String serviceDesc) {
		this.serviceDesc = serviceDesc;
	}
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public Date getServiceRaisedDate() {
		return serviceRaisedDate;
	}
	public void setServiceRaisedDate(Date serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "ServiceTrackerBean [serviceId=" + serviceId + ", serviceDesc="
				+ serviceDesc + ", accId=" + accId + ", serviceRaisedDate="
				+ serviceRaisedDate + ", status=" + status + "]";
	}
	
	


}
