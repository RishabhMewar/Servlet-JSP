package com.capgemini.swissbank.exception;

public class BankException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2328472068401728048L;

	public BankException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankException(String message) {
		super(message);
		// This is a simple exception no kidding
	}

}
