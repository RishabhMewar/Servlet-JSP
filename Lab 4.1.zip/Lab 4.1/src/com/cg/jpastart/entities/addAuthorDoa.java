package com.cg.jpastart.entities;

public interface addAuthorDoa {
	
	public int addAuthor(Author author) thorws AuthorException;
	public Author deleteAuthor(int id) thorws AuthorException;
	public Author findAuthor(int id) thorws AuthorException;
	public List<Author> viewAllAuthor() thorws AuthorException;

}
