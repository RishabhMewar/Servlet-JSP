package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


public class EmployeeTest {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		Employee emp = new Employee();
		emp.setEmployeeName(" Aamir Khan ");
		emp.setEmployeeSalary(8900000);
		em.persist(emp);
		
		
		
		/*Employee emp1 = em.find(Employee.class, 4);
		if(emp1==null)
		{
			System.out.println(" Employee not found ");
		}
		else
		{
			emp1.setEmployeeName(" Shyam ");
			em.merge(emp1);
			System.out.println(" Employee name updated successfully ");
			emp1.setEmployeeSalary(70000);
			System.out.println(emp1.getEmployeeName()+" "+emp1.getEmployeeId()+" "+emp1.getEmployeeSalary());
		}*/
		
		
		/*Query qry = em.createQuery("select e from Employee e");
		List list = qry.getResultList();
		
		for(Object obj : list)
		{
			Employee emp2=(Employee) obj;
			System.out.println(emp2.getEmployeeName()+" "+emp2.getEmployeeId()+" "+emp2.getEmployeeSalary());
		}*/
		
		/*TypedQuery<Employee> qry1 = em.createQuery("from Employee",Employee.class);
		List<Employee> list1 = qry1.getResultList();
		for(Employee emp3  : list1)
		{
			System.out.println(emp3.getEmployeeName()+" "+emp3.getEmployeeId()+" "+emp3.getEmployeeSalary());
		}*/
		
		
		/*TypedQuery<Employee> qry2 = em.createQuery("from Employee where employeeId=4",Employee.class);
		//but it does not give multiple values
		Employee emp4= qry2.getSingleResult();
		System.out.println(emp4.getEmployeeName()+" "+emp4.getEmployeeId()+" "+emp4.getEmployeeSalary());*/
		
		
		/*TypedQuery<Employee> qry3 = em.createQuery("from Employee where employeeId=?",Employee.class);
		//but it does not give multiple values
		qry3.setParameter(1, 4);
		Employee emp5= qry3.getSingleResult();
		System.out.println(emp5.getEmployeeName()+" "+emp5.getEmployeeId()+" "+emp5.getEmployeeSalary());*/
		
		
		/*TypedQuery<Employee> qry3 = em.createQuery("from Employee where employeeId:id",Employee.class);
		//but it does not give multiple values
		qry3.setParameter("id", 4);
		Employee emp5= qry3.getSingleResult();
		System.out.println(emp5.getEmployeeName()+" "+emp5.getEmployeeId()+" "+emp5.getEmployeeSalary());
		*/
		
		//NamedQuery
		/*TypedQuery<Employee> qry = em.createNamedQuery("viewAllEmployees", Employee.class);
		List<Employee> list = qry.getResultList();
		for(Employee emp  : list)
		{
			System.out.println(emp.getEmployeeName()+" "+emp.getEmployeeId()+" "+emp.getEmployeeSalary());
		}*/
		em.getTransaction().commit();
		System.out.println(" employee added to database ");
		em.close();
		emf.close();

	}

}
